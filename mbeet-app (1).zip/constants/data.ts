import { DashboardItems, NavItem } from '@/types';

export type User = {
  id: number;
  name: string;
  role: string;
  location: string;
  phone: string;
  email: string;
  verified: boolean;
};
export const users: User[] = [
  {
    id: 1,
    name: 'فياض',
    role: 'عميل',
    location: 'الاسكندرية',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  },
  {
    id: 1,
    name: 'محمد يسرى',
    role: 'عميل',
    location: 'مصر',
    phone: '01000962127',
    email: 'mohammed.yuossry@gmail.com',
    verified: true
  }
];

export type Employee = {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  gender: string;
  date_of_birth: string; // Consider using a proper date type if possible
  street: string;
  city: string;
  state: string;
  country: string;
  zipcode: string;
  longitude?: number; // Optional field
  latitude?: number; // Optional field
  job: string;
  profile_picture?: string | null; // Profile picture can be a string (URL) or null (if no picture)
};

export const navItems: NavItem[] = [
  {
    title: 'لوحة التحكم',
    href: '/dashboard',
    icon: 'dashboard',
    label: 'لوحة التحكم'
  },
  {
    title: 'إدارة المستخدمين',
    href: '/dashboard/user',
    icon: 'user',
    label: 'إدارة المستخدمين'
  },
  {
    title: 'إدارة الوحدات',
    href: '/dashboard/units',
    icon: 'units',
    label: 'إدارة الوحدات'
  },
  {
    title: 'إدارة الحجوزات',
    href: '/dashboard/requests',
    icon: 'requests',
    label: 'إدارة الحجوزات'
  },
  {
    title: 'إدارة التقييمات',
    href: '/dashboard/reviews',
    icon: 'reviews',
    label: 'إدارة التقييمات'
  },
  {
    title: 'الرسائل',
    href: '/dashboard/messages',
    icon: 'messages',
    label: 'الرسائل'
  },
  {
    title: 'اعدادات الموقع',
    href: '/dashboard/settings',
    icon: 'settings',
    label: 'اعدادات الموقع'
  }
];

export const dashboardItems: DashboardItems[] = [
  {
    title: 'إجمالي الارباح',
    value: '100,990 $',
    icon: 'dollar'
  },
  {
    title: 'إجمالي الوحدات',
    value: '80,890',
    icon: 'units'
  },
  {
    title: 'إجمالي المستخدمين',
    value: '750,890',
    icon: 'user'
  }
];

export type Units = {
  id: number;
  name: string;
  description: string;
  bedrooms: number;
  bathrooms: number;
  size: number;
  price: number;
  role: 'rent' | 'sale';
  location: string;
  image: string;
};
export const units: Units[] = [
  {
    id: 1,
    name: 'شاليه فاخر للإيجار في الساحل الشمالي',
    description:
      'يقع في موقع استراتيجي قريب من البحر. يتوفر الشاليه على جميع وسائل الراحة والترفيه التي تحتاجها لقضاء عطلة',
    location: 'الاسكندرية',
    price: 5000,
    role: 'rent',
    size: 300,
    bedrooms: 4,
    bathrooms: 2,
    image: ''
  },
  {
    id: 2,
    name: 'شاليه فاخر للإيجار في المدينة النصرانية',
    description:
      'يقع في موقع استراتيجي بالمدينة النصرانية. يتوفر الشاليه على جميع وسائل الراحة والترفيه التي تحتاجها لقضاء عطلة',
    location: 'السعوديةِ',
    price: 3000,
    role: 'rent',
    size: 200,
    bedrooms: 3,
    bathrooms: 1,
    image: ''
  },
  {
    id: 3,
    name: 'شاليه فاخر للبيع في الساحل الشمالي',
    description:
      'يقع في موقع استراتيجي قريب من البحر. يتوفر الشاليه للبيع بالسعر 2,500,000 جنيه',
    location: 'السعوديةِ',
    price: 2500000,
    role: 'sale',
    size: 200,
    bedrooms: 2,
    bathrooms: 1,
    image: ''
  },
  {
    id: 4,
    name: 'شاليه فاخر للإيجار في المدينة النصرانية',
    description:
      'يقع في موقع استراتيجي بالمدينة النصرانية. يتوفر الشاليه على جميع وسائل الراحة والترفيه التي تحتاجها لقضاء عطلة',
    location: 'السعوديةِ',
    price: 3000,
    role: 'rent',
    size: 250,
    bedrooms: 4,
    bathrooms: 2,
    image: ''
  },
  {
    id: 5,
    name: 'شاليه فاخر للبيع في الساحل الشمالي',
    description:
      'يقع في موقع استراتيجي قريب من البحر. يتوفر الشاليه للبيع بالسعر 5,000,000 جنيه',
    location: 'السعوديةِ',
    price: 5000000,
    role: 'sale',
    size: 300,
    bedrooms: 5,
    bathrooms: 3,
    image: ''
  }
];

export type Review = {
  id: string;
  name: string;
  description: string;
  location: string;
  date: Date;
  review: 1 | 2 | 3 | 4 | 5;
};
export const reviews: Review[] = [
  {
    id: '#C07234',
    name: 'مريم سيد',
    description:
      'إقامة رائعة! الشاليه كان نظيفًا جدًا ومجهزًا بكل ما نحتاجه. الموقع قريب جدًا من الشاطئ والمطاعم. حمام السباحة الخاص كان مدهشًا! بالتأكيد سأعود مرة أخرىِ',
    location: 'مصر',
    date: new Date('2024-08-20T00:42:00'),
    review: 1
  },
  {
    id: '#C07234',
    name: 'مريم سيد',
    description:
      'إقامة رائعة! الشاليه كان نظيفًا جدًا ومجهزًا بكل ما نحتاجه. الموقع قريب جدًا من الشاطئ والمطاعم. حمام السباحة الخاص كان مدهشًا! بالتأكيد سأعود مرة أخرىِ',
    location: 'مصر',
    date: new Date('2024-08-16T00:42:00'),
    review: 5
  },
  {
    id: '#C07234',
    name: 'مريم سيد',
    description:
      'إقامة رائعة! الشاليه كان نظيفًا جدًا ومجهزًا بكل ما نحتاجه. الموقع قريب جدًا من الشاطئ والمطاعم. حمام السباحة الخاص كان مدهشًا! بالتأكيد سأعود مرة أخرىِ',
    location: 'مصر',
    date: new Date('2024-08-20T00:42:00'),
    review: 2
  },
  {
    id: '#C07234',
    name: 'مريم سيد',
    description:
      'إقامة رائعة! الشاليه كان نظيفًا جدًا ومجهزًا بكل ما نحتاجه. الموقع قريب جدًا من الشاطئ والمطاعم. حمام السباحة الخاص كان مدهشًا! بالتأكيد سأعود مرة أخرىِ',
    location: 'مصر',
    date: new Date('2024-08-20T00:42:00'),
    review: 3
  },
  {
    id: '#C07234',
    name: 'مريم سيد',
    description:
      'إقامة رائعة! الشاليه كان نظيفًا جدًا ومجهزًا بكل ما نحتاجه. الموقع قريب جدًا من الشاطئ والمطاعم. حمام السباحة الخاص كان مدهشًا! بالتأكيد سأعود مرة أخرىِ',
    location: 'مصر',
    date: new Date('2024-08-20T00:42:00'),
    review: 4
  },
  {
    id: '#C07234',
    name: 'مريم سيد',
    description:
      'إقامة رائعة! الشاليه كان نظيفًا جدًا ومجهزًا بكل ما نحتاجه. الموقع قريب جدًا من الشاطئ والمطاعم. حمام السباحة الخاص كان مدهشًا! بالتأكيد سأعود مرة أخرىِ',
    location: 'مصر',
    date: new Date('2024-08-20T00:42:00'),
    review: 5
  },
  {
    id: '#C07234',
    name: 'مريم سيد',
    description:
      'إقامة رائعة! الشاليه كان نظيفًا جدًا ومجهزًا بكل ما نحتاجه. الموقع قريب جدًا من الشاطئ والمطاعم. حمام السباحة الخاص كان مدهشًا! بالتأكيد سأعود مرة أخرىِ',
    location: 'مصر',
    date: new Date('2024-08-20T00:42:00'),
    review: 5
  },
  {
    id: '#C07234',
    name: 'مريم سيد',
    description:
      'إقامة رائعة! الشاليه كان نظيفًا جدًا ومجهزًا بكل ما نحتاجه. الموقع قريب جدًا من الشاطئ والمطاعم. حمام السباحة الخاص كان مدهشًا! بالتأكيد سأعود مرة أخرىِ',
    location: 'مصر',
    date: new Date('2024-08-20T00:42:00'),
    review: 5
  },
  {
    id: '#C07234',
    name: 'مريم سيد',
    description:
      'إقامة رائعة! الشاليه كان نظيفًا جدًا ومجهزًا بكل ما نحتاجه. الموقع قريب جدًا من الشاطئ والمطاعم. حمام السباحة الخاص كان مدهشًا! بالتأكيد سأعود مرة أخرىِ',
    location: 'مصر',
    date: new Date('2024-08-20T00:42:00'),
    review: 5
  }
];

export type Chat = {
  id: string;
  name: string;
  message: string[];
  date: Date;
  seen: boolean;
};
export const chats: Chat[] = [
  {
    id: '1235123easdasd',
    name: 'محمد يسرى',
    message: ['هذا النص هو مثال لنص يمكن ان يستبدل في نفس المساحة'],
    date: new Date('2024-08-13T19:22:00'),
    seen: true
  },
  {
    id: 'asxx32415432%#@!$',
    name: 'فياض',
    message: [
      'هذا النص هو مثال لنص يمكن ان يستبدل فيasd sad sadشسيشسي شسي نفس المساحة'
    ],
    date: new Date('2024-08-11T00:42:00'),
    seen: false
  },
  {
    id: 'asxx32415432%#@!$',
    name: 'محمد فياض',
    message: [
      'هذا النص هو مثال لنص يمكن ان يستبدل فيasd sad sadشسيشسي شسي نفس المساحة'
    ],
    date: new Date('2024-08-13T15:42:00'),
    seen: false
  }
];
