import { Card } from '@/components/ui/card';

export const PaymentsTab = () => {
  return (
    <>
      <Card className="p-4 lg:px-14">payments</Card>
    </>
  );
};
